        <div id="footer" class="footer">
            <div class="container">
                <div class="col-md-12 text-center">
                    <ul class="list-inline">
                       <a href="/" rel="nofollow">HOME</a> -  <a href="/contact" rel="nofollow">CONTACT</a> - <a href="/privacy" rel="nofollow">PRIVACY</a> - <a href="/dmca" rel="nofollow">DMCA</a>

                    </ul>
                    <p class="text-muted">Copyright &copy; <?php echo date('Y'); ?> <a href="/"><?php echo $site_name; ?></a></p>
                </div>
            </div>
        </div>