var phrases = new Array();
phrases["contact_success"] = "Thank you. Your message has been sent.";