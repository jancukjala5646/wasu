<?php
     error_reporting(E_ALL);
     ini_set('display_errors', 0);

?>
<link href="/material/css/bootstrap.min.css" rel="stylesheet">	  
<link href="/material/css/bootstrap-material-design.css" rel="stylesheet">
<link href="/material/css/ripples.css" rel="stylesheet">
<link href="/material/css/jquery.dropdown.css" rel="stylesheet">
<link href="/style.css" rel="stylesheet" type="text/css">
<link href="/favicon.ico" rel="shortcut icon" type="image/x-icon"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,500" type="text/css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>