<?php
include($_SERVER['DOCUMENT_ROOT']."/PENGATURAN/config.php");
include($_SERVER['DOCUMENT_ROOT']."/PENGATURAN/fungsi.php");
$domains = $_SERVER['HTTP_HOST'];
$file = $_GET['file'];
$title = str_replace('-', ' ', $file);
$title = str_replace('download', '', $title);
$title = str_replace('.pdf', '', $title);
$title = str_replace('Printable', '', $title);
$title = str_replace('2020', '', $title);

$title = preg_replace('/[^A-Za-z0-9 ]/', ' ', $title);
$cano = ''.$domain.'/'.$file.'.pdf';
$judul = ucwords($title);
$md5 = ucwords($title);
$domen = $_SERVER['HTTP_HOST'];
$gambar = preg_replace('/[0-9]+/', '', $title);
$pages = rand(400,700);
function poplist() {
	if (file_exists('KEY/pop.txt')) {
		$myfile = fopen("KEY/pop.txt", "r") or die("Unable to open file!");
		while( $i < 5) {
			$seek = rand(0, filesize("KEY/pop.txt"));
			if ($seek > 0) {
				fseek($myfile, $seek);
				fgets($myfile);
			}
			$kiwot = fgets($myfile);
			if (!empty($kiwot)) {
				include($_SERVER['DOCUMENT_ROOT']."/PENGATURAN/config.php");
				$url = $linkfont($kiwot);
				$titled =  ltrim(rtrim($titled));
				$url = str_replace (' ',''.$linkstyle.'',$url);
                                $judul = $kiwot;
$gambar = preg_replace('/[0-9]+/', '', $judul);
$gambar = str_replace (' ','-',$gambar);
				echo '<div class="thumb thumb--small">
    <a href="http://'.$domen.'/'.$url.''.$linkstyle.''.$unixurlcode.'.pdf" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="http://'.$domen.'/'.$url.''.$linkstyle.''.$unixurlcode.'.pdf" class="cover__img" style="background-image:url(https://3.bp.blogspot.com/-GPUCXsOkt9A/WylLV5Wd2dI/AAAAAAAAAAM/-4sYWZiRKGEvwuFQ9mFaXBsrqyLiwraUACLcBGAs/s1600/largepreview.png);">
                    <img  src="http://'.$domen.'/'.$gambar.'.jpg" class="cover__img"onerror="this.src=\'https://3.bp.blogspot.com/-GPUCXsOkt9A/WylLV5Wd2dI/AAAAAAAAAAM/-4sYWZiRKGEvwuFQ9mFaXBsrqyLiwraUACLcBGAs/s1600/largepreview.png\'">
                </div>
            </div>
        </div>
    </a>
    <a href="http://'.$domen.'/'.$url.''.$linkstyle.''.$unixurlcode.'.pdf" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">'.ucwords($judul).'</h1>
    </a>
</div>
';
}
			$i++;
		}
		fclose($myfile);
	}
}

function agcmasterclass($haystack, $needles=array(), $offset=0) {
        $chr = array();
        foreach($needles as $needle) {
                $res = stripos($haystack, $needle, $offset);
                if ($res !== false) $chr[$needle] = $res;
        }
        if(empty($chr)) return false;
        return min($chr);
}
$dmcaurl = $_SERVER['REQUEST_URI'];
$juduldmca = str_replace('-', ' ', $dmcaurl);
$dmca		= file_get_contents('dmca.txt', true);
$dmca		= explode(',',$dmca);
if (agcmasterclass($juduldmca,$dmca))
{
$urlredirect = '/dl.php';
header("HTTP/1.1 301 Moved Permanently");
header( "Location: $urlredirect" );
}
$ads = ''.$lpdomain.'/dl.php?file='.$title.'&subId='.$file.'';
?>
<!DOCTYPE html>
<html class="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta content="NOINDEX, NOFOLLOW" name="robots">
    <meta name="rem:pc" content="landers;Book">
    <script crossorigin="anonymous" src="https://cdnjs.cloudflare.com/ajax/libs/js-polyfills/0.1.42/polyfill.min.js"></script>

    

    <title>Download <?php echo $judul; ?> PDF Book- <?php echo strtoupper( $domains ); ?></title>
    <link href="/lp5/asset/images/book-ico.png" rel="shortcut icon">
    <link href="/lp5/asset/images/book-ico-sm.png" rel="icon" type="image/png">

    <meta name="lpl:r" content="lcat"/>
    <meta name="lpl:d" content="z=31267"/>
    <meta name="lpl:q" content="z,dp,q,s1,s2,s3,s4,s5,lcat,lpage,lang,var,country"/>
    <meta name="lpl:$" content="email=#email,password=#password"/>
    <meta name="lpl:$" content="q=.media--title"/>
    <meta name="lpl:t" content="m=.message--title"/>
    <meta name="lpl:t" content="q=.media--title"/>

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/css/bootstrap-select.min.css">
    <link rel="stylesheet" href="/lp5/asset/css/3ea616374ac544c4794302fbdcc6365a-1573706501.css">
    <style>.media--title{word-wrap: break-word;}</style>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,600,700" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="/lp5/asset/css/c6b27c61a7a8735fe7a2802fcdf3375b-1573706501.css" rel="stylesheet">
        <script type="application/javascript" src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script type="application/javascript" src="/lp5/asset/js/9106ffcd2ab3dd974606051bf7f038d4-1576604836.js"></script>


</head>
<body class="" data-site="books">

    <div class="onloader"></div>

    <!-- nap pop -->
    <div class="nap-pop">
    <div class="nap-pop__inner">
        <img src="/read/asset/img/dotted-loading.gif" width="100" alt="">
        <p></p>
    </div>
</div>
        
<script type="text/javascript" src="https://www.google.com/books/jsapi.js"></script>
<script type="text/javascript">
$(document).ready(function(){

    var $readerModal = $('.reader__modal'),
        $pageNavNext = $('.reader-trigger-pagenext'),
        $pageNavPrev = $('.reader-trigger-pageprev'),
        $zoomIn = $('.reader-trigger-zoomin'),
        $zoomOut = $('.reader-trigger-zoomout');

    function showReaderModal() {
        $readerModal.show();
        $zoomIn.add($zoomOut).add($pageNavNext).add($pageNavPrev).off('click');
        setTimeout(function () {
            $readerModal.addClass('show');
        }, 1000);
    }

    google.books.load();

    function initialize() {
        var viewer = new google.books.DefaultViewer(document.getElementById('readerViewer'));
        window.viewer = viewer;
        function readProgress(page) {
            return Math.round(page / <?php echo $pages;?> * 100);
        }
        var $pageNumber = $('.reader-pagenum'),
            $pagePercentage = $('.reader-pagepercentage'),
            $readerProgress = $('.reader__scrubber__progress'),
            randNum = Math.floor(Math.random() * (5 - 3)) + 3,
            now = Date.now();

        viewer.load('ISBN:', function () {
            setTimeout(function () {
                $('.reader__loader').fadeOut('slow');
                $('.readerViewerFb').removeClass('d-none');
                $readerModal.css("height", "100%");
            }, 1000);
            var $fbReader = $('.readerViewerFb'),
                $fbContent = $fbReader.find('ul');
            function getPagesTop() {
                return $fbContent.find('li').map(function (page) {
                    return page == 0 ? 0 : $(this).position().top * ($fbContent.css('zoom') || 1.0);
                });
            }
            $zoomOut.click(function () {
                $fbContent.css('zoom', '' + (parseFloat($fbContent.css('zoom') || 1.0) - 0.1));
            });
            $zoomIn.click(function () {
                $fbContent.css('zoom', '' + (parseFloat($fbContent.css('zoom') || 1.0) + 0.1));
            });
            $pageNavNext.click(function () {
                var pagesTop = getPagesTop();
                var page;
                for (page = 0; page < pagesTop.length; page++) {
                    if ($fbReader.scrollTop() + 10 < pagesTop[page]) {
                        break;
                    }
                }
                page--;
                if (pagesTop[page + 1]) {
                    $fbReader.scrollTop(pagesTop[page + 1]);
                }
            });
            $pageNavPrev.click(function () {
                var pagesTop = getPagesTop();
                var page;
                for (page = 0; page < pagesTop.length; page++) {
                    if ($fbReader.scrollTop() + 10 < pagesTop[page]) {
                        break;
                    }
                }
                page--;
                if (pagesTop[page - 1] !== undefined) {
                    $fbReader.scrollTop(pagesTop[page - 1]);
                }
            });
            setInterval(function () {
                var pagesTop = getPagesTop();
                var page;
                for (page = 0; page < pagesTop.length; page++) {
                    if ($fbReader.scrollTop() + 10 < pagesTop[page]) {
                        break;
                    }
                }
                $pageNumber.text(page);
                var progress = readProgress(page);
                $pagePercentage.text(progress);
                $readerProgress.css('width', '' + readProgress(page) + '%');
                if(Date.now() - now > 5000 && page >= randNum) {
                    showReaderModal();
                }
            }, 250);
        }, function(_) {
            if (viewer.getPageNumber() === undefined) {
                var pages = [];
                while (true) {
                    var id = viewer.getPageId();
                    if (pages.indexOf(id) >= 0) {
                        break;
                    }
                    pages.push(id);
                    viewer.nextPage();
                }
                viewer.getPageNumber = function () {
                    return pages.indexOf(viewer.getPageId()) + 1;
                }
                viewer.goToPage = function (number) {
                    viewer.goToPageId(pages[number - 1]);
                }
                viewer.goToPage(1);
            }
            $zoomIn.click(viewer.zoomIn);
            $zoomOut.click(viewer.zoomOut);
            $pageNavNext.click(viewer.nextPage);
            $pageNavPrev.click(viewer.previousPage);

            $('.reader__loader').fadeOut('slow');

            setInterval(function () {
                var page = viewer.getPageNumber();
                $pageNumber.text(page);
                var progress = readProgress(page);
                $pagePercentage.text(progress);
                $readerProgress.css('width', '' + progress + '%');
                if(Date.now() - now > 5000 && page >= randNum) {
                    showReaderModal();
                }
            }, 250);
            setTimeout(function () {
                for (var i=0; i<5; i++)
                    viewer.zoomOut();
            }, 100);
            $('#readerViewer').removeClass('d-none');
        });
    }
    google.books.setOnLoadCallback(initialize);
});
</script>

<!-- header -->


<div class="signin-modal" style="display: none;">

    <div class="signin-modal__holder">

        <!-- sign in close -->
        <div class="signin-modal__close js-close-signinmodal">
            <i class="fa fa-close fa-lg" aria-hidden="true"></i>
        </div>

        <!-- sign in default -->
        <form id="signinform">
            <div class="signin-modal__default">
                <h1 class="tr">sign in</h1>
                <div class="form-group">
                    <label for="email" class="tr">Email*</label>                    <input class="form-control tr" type="text" id="signinemail" data-tr-holder="emailHolder" placeholder="Enter your email">
                </div>
                <div class="form-group">
                    <label for="password" class="tr">Password*</label>                    <p class="label-note first-letter-cap tr" id="forgotpass">forgot password?</p>
                    <input class="form-control tr" type="password" id="signinpassword" data-tr-holder="passwordHolder" placeholder="Enter your password (min 6 characters)">
                    <div class="invalid-feedback" style="display: none;"></div>
                </div>
                <button class="btn btn--primary tr" type="submit">sign in</button>
                <div class="subform-link" style="display: block;">
                    <div class="tr js-close-signinmodal">Don't have an account? Sign Up</div>
                </div>
            </div>
        </form>

        <!-- forgot password -->
        <form id="resetpassform" style="display: none;">
            <div class="signin-modal__resetpassword">
                <h1 class="tr">reset password</h1>
                <p class="text-muted first-letter-cap tr">enter your email address and we'll send you a link to reset your password.</p>
                <div class="form-group">
                    <label for="emailreset" class="tr">Email*</label>                    <input class="form-control tr" type="text" id="emailreset" data-tr-holder="emailHolder" placeholder="Enter your email">
                    <div class="invalid-feedback" style="display: none;"></div>
                </div>
                <button class="btn btn--primary tr" type="submit">submit</button>
                <div class="subform-link">
                    <div class="tr" id="signinmodal-default">Back to Sign In</div>
                </div>
            </div>
        </form>

    </div>
</div>
<header>

    <div class="head">
        <a class="logo" href="/">
            <img src="/lp5/asset/images/ebook.png" alt="<?php echo $site_name;?>">
            <h1 class="word-wrap"><?php echo $site_name;?></h1>
        </a>
 <div class="mobilenav_btn" onClick="open_nav()"><i id="mobile-nav-fa" class="fa fa-navicon"></i></div>
        <div class="mobilenav">
            <a href="/" class="mntitle">HOME</a>
            <a href="" data-url="<?php echo $ads;?>" data-lpl="z,dp,s1,s2,s3,s4,s5=v,q,lcat,lpage,lang,var,c_bg,c_img1,c_img2,imdb_id" class="mntitle mntitle_primary">SIGN IN</a>
            <a href="" data-url="<?php echo $ads;?>" data-lpl="z,dp,s1,s2,s3,s4,s5=v,q,lcat,lpage,lang,var,c_bg,c_img1,c_img2,imdb_id" class="mntitle mntitle_primary">SIGN UP</a>
            
                   </div>

        <div class="nav_box">
            <div class="nav">
               
                <a href="" onclick="event.preventDefault();" class="nav_link js-open-signinmodal">SIGN IN</a>
                <a href="" class="nav_primary" data-url="<?php echo $ads;?>" data-lpl="z,dp,s1,s2,s3,s4,s5=v,q,lcat,lpage,lang,var,c_bg,c_img1,c_img2,imdb_id">SIGN UP</a>
                <a href="" class="nav_search"><font size="7"><i class="fa fa-search-plus" aria-hidden="true"></i></font></a>
            </div>
        </div>
    </div>

</header>

<div class="head_search-nav">
    <div class="head_search-nav_main">
        <div class="search-field">
    <form action="/search" method="get">
        <input type="text" name="q" placeholder=" Search by Title, Author... ">
        <input type="submit" name="" value="Search">
    </form>
</div>    </div>
</div>
<div class="height100"></div>

<section>
    <div class="container">
        <div class="reader">
            <div class="reader__info">
                <h2 class="subheading">Now reading:</h2>
                <h1 class="heading-md media--title"><?php echo $judul; ?></h1>
            </div>
            <nav class="reader__nav">
                <div class="reader__nav__left">
                    <ul>
                        <li><a  href="" data-url="<?php echo $ads;?>" data-lpl="z,dp,s1,s2,s3,s4,s5=v,q,lcat,lpage,lang,var,c_bg,c_img1,c_img2,imdb_id"><i class="fa fa-bookmark" aria-hidden="true"></i></a></li>
                        <li><a  href="" data-url="<?php echo $ads;?>" data-lpl="z,dp,s1,s2,s3,s4,s5=v,q,lcat,lpage,lang,var,c_bg,c_img1,c_img2,imdb_id"><i class="fa fa-moon-o" aria-hidden="true"></i></a></li>
                    </ul>
                </div>
                <div class="reader__nav__right">
                    <ul>
                        <li class="reader-trigger-zoomin"><i class="fa fa-search-plus" aria-hidden="true"></i></li>
                        <li class="reader-trigger-zoomout"><i class="fa fa-search-minus" aria-hidden="true"></i></li>
                    </ul>
                </div>
            </nav>
            <div class="reader__wrapper">

                <div class="reader__loader">
                    <img src="/read/asset/img/loading.gif" alt="loader">
                </div>

                <div class="reader__modal">
                    <div class="reader__modal__inner">
                        <div class="reader__modal__img-holder">
                            <img src="<?php echo sanitize_title($gambar);?>.jpg" alt="<?php echo sanitize_title($gambar);?>.jpg">
                            <div class="icon-rounded">
                                <i class="typcn typcn-lock-open"></i>
                            </div>
                        </div>
                        <h1 class="heading-md">Join now to keep reading!</h1>
                        <p>Your preview has ended! Become a member today to continue reading for Free!</p>
                        <div class="btn-holder">
                            <a href="" data-url="<?php echo $ads;?>" data-lpl="z,dp,s1,s2,s3,s4,s5=v,q,lcat,lpage,lang,var,c_bg,c_img1,c_img2,imdb_id" class="btn btn--large btn--primary">Create Free Account</a>
                        </div>
                    </div>
                </div>

                <div id="readerViewer" class="d-none"></div>
                <div class="readerViewerFb d-none">
                    <ul style="zoom: 0.5">
                        <li style="background-image: url(<?php echo sanitize_title($gambar);?>.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                        <li style="background-image: url(/read/asset/img/fb-page-intro.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                        <li style="background-image: url(/read/asset/img/fb-page-1.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-2.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-3.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-4.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                                    <li style="background-image: url(/read/asset/img/fb-page-5.jpg);"><img src="/read/asset/img/doc-cover-shadow-xlarge.png" class="img-fluid"></li>
                                            </ul>
                </div>

                <nav class="reader__page-nav">
                    <ul>
                        <li class="reader-trigger-pageprev"><i class="typcn typcn-chevron-left"></i></li>
                        <li class="reader-trigger-pagenext"><i class="typcn typcn-chevron-right"></i></li>
                    </ul>
                </nav>

            </div>
            <div class="reader__scrubber">
                <span>Read</span>
                <div class="reader__scrubber__track">
                    <div class="reader__scrubber__progress"></div>
                </div>
                <span class="reader__scrubber__percentage"><span class="reader-pagepercentage"></span>%</span>
            </div>
            <div class="reader__footer">
                <ul>
                    <li class="reader-trigger-pageprev"><i class="typcn typcn-chevron-left"></i></li>
                    <li>Page <span class="reader-pagenum"></span> of  <?php echo $pages;?> </li>
                    <li class="reader-trigger-pagenext"><i class="typcn typcn-chevron-right"></i></li>
                </ul>
            </div>

            <div class="seperator"></div>

            <div class="reader__footer-info">
                <div class="reader__footer-info__col">
                    <!-- actions list -->
                    <ul class="actions-list">
    <li>
        <a href="" data-url="<?php echo $ads;?>" data-lpl="z,dp,s1,s2,s3,s4,s5=v,q,lcat,lpage,lang,var,c_bg,c_img1,c_img2,imdb_id">
            <i class="fa fa fa-heart fa-lg"></i>
            <span>Add to Favorites</span>
        </a>
    </li>
    <li>
        <a href="" data-url="<?php echo $ads;?>" data-lpl="z,dp,s1,s2,s3,s4,s5=v,q,lcat,lpage,lang,var,c_bg,c_img1,c_img2,imdb_id">
            <i class="fa fa-list fa-lg"></i>
            <span>Add to Reading List</span>
        </a>
    </li>
</ul>                </div>
                <div class="reader__footer-info__col">
                    <div class="btn--wrapper">
                        <a href="" data-url="<?php echo $ads;?>" data-lpl="z,dp,s1,s2,s3,s4,s5=v,q,lcat,lpage,lang,var,c_bg,c_img1,c_img2,imdb_id" class="btn"><i class="fa fa-download"></i> Download</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>

    </script>
</section>

<div class="height60"></div>

<!-- footer -->
<footer>
    <div class="us_link">
        <a href="/dmca">DMCA</a>
        <a href="/privacy">Privacy Policy</a>
        <a href="/contact">Contact Us</a>
        <a href="/feed">Feed</a>
    </div>
    <p><i class="fa fa-copyright" aria-hidden="true"></i> <?php echo date('Y');?><span class="media--title word-wrap tr">Read <?php echo $judul; ?> eBook</span> Inc. All rights reserved.</p>
</footer>



        <script type="application/javascript" src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/jquery.validate.min.js"></script>
    <script type="application/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/bootstrap-select.min.js"></script>
    <script type="application/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/URI.js/1.19.1/URI.min.js"></script>
        <script type="application/javascript" src="/lp5/asset/js/5e0f1499cb66751aaed90ea44f057f12-1573706501.js">
    </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha256-C8oQVJ33cKtnkARnmeWp6SDChkU+u7KvsNMFUzkkUzk=" crossorigin="anonymous"></script>
    <script src="/lp5/asset/js/0eb0f43c492ad2f54f02f93146b91ce9-1573706501.js" type="text/javascript"></script>
<?php include('histats.php')?>
</body>
</html>