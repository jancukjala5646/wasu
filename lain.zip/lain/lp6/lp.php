
<!DOCTYPE html>
<html class="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta content="NOINDEX, NOFOLLOW" name="robots">
    <meta name="rem:pc" content="landers;Book">
    <script crossorigin="anonymous" src="https://cdnjs.cloudflare.com/ajax/libs/js-polyfills/0.1.42/polyfill.min.js"></script>

    
    <!-- Matomo Tag Manager -->
<script type="text/javascript">
    var _mtm = _mtm || [];
    _mtm.push({'mtm.startTime': (new Date().getTime()), 'event': 'mtm.Start'});
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src='https://collecting.click/js/container_ecko3JmF.js'; s.parentNode.insertBefore(g,s);
</script>
<!-- End Matomo Tag Manager -->

    <title>Read Blacklisted by Gena Showalter Online - Books</title>
    <link href="lp5/asset/image/book-ico.png" rel="shortcut icon">
    <link href="lp5/asset/image/book-ico-sm.png" rel="icon" type="image/png">

    <meta name="lpl:r" content="lcat"/>
    <meta name="lpl:d" content="z=31267"/>
    <meta name="lpl:q" content="z,dp,q,s1,s2,s3,s4,s5,lcat,lpage,lang,var,country"/>
    <meta name="lpl:$" content="email=#email,password=#password"/>
    <meta name="lpl:$" content="q=.media--title"/>
    <meta name="lpl:t" content="m=.message--title"/>
    <meta name="lpl:t" content="q=.media--title"/>

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/css/bootstrap-select.min.css">
    <link rel="stylesheet" href="https://best-online-books.com/combine/3ea616374ac544c4794302fbdcc6365a-1573706501">
    <style>.media--title{word-wrap: break-word;}</style>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,600,700" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://best-online-books.com/combine/c6b27c61a7a8735fe7a2802fcdf3375b-1573706501" rel="stylesheet">
        <script type="application/javascript" src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script type="application/javascript" src="https://best-online-books.com/combine/9106ffcd2ab3dd974606051bf7f038d4-1576604836"></script>


</head>
<body class="" data-site="books">

    <div class="onloader"></div>

    <!-- nap pop -->
    <div class="nap-pop">
    <div class="nap-pop__inner">
        <img src="/themes/common-spin-landers/assets/images/dotted-loader.gif" width="100" alt="">
        <p></p>
    </div>
</div>
        

<!-- header -->


<div class="signin-modal" style="display: none;">

    <div class="signin-modal__holder">

        <!-- sign in close -->
        <div class="signin-modal__close js-close-signinmodal">
            <i class="fa fa-close fa-lg" aria-hidden="true"></i>
        </div>

        <!-- sign in default -->
        <form id="signinform">
            <div class="signin-modal__default">
                <h1 class="tr">sign in</h1>
                <div class="form-group">
                    <label for="email" class="tr">Email*</label>                    <input class="form-control tr" type="text" id="signinemail" data-tr-holder="emailHolder" placeholder="Enter your email">
                </div>
                <div class="form-group">
                    <label for="password" class="tr">Password*</label>                    <p class="label-note first-letter-cap tr" id="forgotpass">forgot password?</p>
                    <input class="form-control tr" type="password" id="signinpassword" data-tr-holder="passwordHolder" placeholder="Enter your password (min 6 characters)">
                    <div class="invalid-feedback" style="display: none;"></div>
                </div>
                <button class="btn btn--primary tr" type="submit">sign in</button>
                <div class="subform-link" style="display: block;">
                    <div class="tr js-close-signinmodal">Don't have an account? Sign Up</div>
                </div>
            </div>
        </form>

        <!-- forgot password -->
        <form id="resetpassform" style="display: none;">
            <div class="signin-modal__resetpassword">
                <h1 class="tr">reset password</h1>
                <p class="text-muted first-letter-cap tr">enter your email address and we'll send you a link to reset your password.</p>
                <div class="form-group">
                    <label for="emailreset" class="tr">Email*</label>                    <input class="form-control tr" type="text" id="emailreset" data-tr-holder="emailHolder" placeholder="Enter your email">
                    <div class="invalid-feedback" style="display: none;"></div>
                </div>
                <button class="btn btn--primary tr" type="submit">submit</button>
                <div class="subform-link">
                    <div class="tr" id="signinmodal-default">Back to Sign In</div>
                </div>
            </div>
        </form>

    </div>
</div>
<header>

    <div class="head">
        <a class="logo" href="https://best-online-books.com">
            <img src="lp5/asset/image/index/logo-icon.svg" alt="best-online-books">
            <h1 class="word-wrap">best-online-books</h1>
        </a>

        <div class="mobilenav_btn" onClick="open_nav()"><i id="mobile-nav-fa" class="fa fa-navicon"></i></div>
        <div class="mobilenav">
            <a href="https://best-online-books.com" class="mntitle">HOME</a>
            <a href="" onclick="event.preventDefault();" class="js-open-signinmodal mntitle">SIGN IN</a>
            <a href="" data-url="https://fb.best-online-books.com/tuname.php?n=&amp;z=18734&amp;d=1" data-lpl="z,dp,s1,s2,s3,s4,s5=v,q,lcat,lpage,lang,var,c_bg,c_img1,c_img2,imdb_id" class="mntitle mntitle_primary">SIGN UP</a>
            <span class="mntitle">BOOKS GENRES</span>
            <div class="mnheight">

                                                            <a href="/browse/fiction">Fiction</a>
                                                                                <a href="/browse/non-fiction">Non Fiction</a>
                                                                                <a href="/browse/adult">Adult</a>
                                                                                <a href="/browse/poetry">Poetry</a>
                                                                                <a href="/browse/christian">Christian</a>
                                                                                <a href="/browse/unfinished">Unfinished</a>
                                                                                <a href="/browse/lgbt">Lgbt</a>
                                                                                <a href="/browse/love">Love</a>
                                                                                <a href="/browse/war">War</a>
                                                                                <a href="/browse/animals">Animals</a>
                                                                                <a href="/browse/dark">Dark</a>
                                                                                <a href="/browse/feminism">Feminism</a>
                                                                                <a href="/browse/novella">Novella</a>
                                                                                <a href="/browse/relationships">Relationships</a>
                                                                                <a href="/browse/spirituality">Spirituality</a>
                                                                                <a href="/browse/death">Death</a>
                                                                                <a href="/browse/roman">Roman</a>
                                                                                <a href="/browse/science-fiction-fantasy">Science Fiction Fantasy</a>
                                                                                <a href="/browse/inspirational">Inspirational</a>
                                                                                <a href="/browse/biography-memoir">Biography Memoir</a>
                                                                                <a href="/browse/romantic">Romantic</a>
                                                                                <a href="/browse/united-states">United States</a>
                                                                                <a href="/browse/graphic-novels-comics">Graphic Novels Comics</a>
                                                                                <a href="/browse/textbooks">Textbooks</a>
                                                                                <a href="/browse/anthologies">Anthologies</a>
                                                                                <a href="/browse/teaching">Teaching</a>
                                                                                <a href="/browse/social">Social</a>
                                                                                <a href="/browse/canon">Canon</a>
                                                                                <a href="/browse/holiday">Holiday</a>
                                                                                <a href="/browse/new-york">New York</a>
                                                                                <a href="/browse/medical">Medical</a>
                                                                                <a href="/browse/urban">Urban</a>
                                                                                <a href="/browse/race">Race</a>
                                                                                <a href="/browse/space">Space</a>
                                                                                <a href="/browse/gender">Gender</a>
                                                                                <a href="/browse/futuristic">Futuristic</a>
                                                                                <a href="/browse/sexuality">Sexuality</a>
                                                                                <a href="/browse/disability">Disability</a>
                                                                                <a href="/browse/comics-manga">Comics Manga</a>
                                                                                <a href="/browse/sequential-art">Sequential Art</a>
                                                                                <a href="/browse/adolescence">Adolescence</a>
                                                                                <a href="/browse/occult">Occult</a>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
            </div>
        </div>

        <div class="nav_box">
            <div class="nav">
                <div id="nav" class="nav_list" onMouseMove="open_nav_box()">
                    BOOKS GENRES
                    <div class="nlist">

                                                                                    <a href="/browse/fiction">Fiction</a>
                                                                                                                <a href="/browse/non-fiction">Non Fiction</a>
                                                                                                                <a href="/browse/adult">Adult</a>
                                                                                                                <a href="/browse/poetry">Poetry</a>
                                                                                                                <a href="/browse/christian">Christian</a>
                                                                                                                <a href="/browse/unfinished">Unfinished</a>
                                                                                                                <a href="/browse/lgbt">Lgbt</a>
                                                                                                                <a href="/browse/love">Love</a>
                                                                                                                <a href="/browse/war">War</a>
                                                                                                                <a href="/browse/animals">Animals</a>
                                                                                                                <a href="/browse/dark">Dark</a>
                                                                                                                <a href="/browse/feminism">Feminism</a>
                                                                                                                <a href="/browse/novella">Novella</a>
                                                                                                                <a href="/browse/relationships">Relationships</a>
                                                                                                                <a href="/browse/spirituality">Spirituality</a>
                                                                                                                <a href="/browse/death">Death</a>
                                                                                                                <a href="/browse/roman">Roman</a>
                                                                                                                <a href="/browse/science-fiction-fantasy">Science Fiction Fantasy</a>
                                                                                                                <a href="/browse/inspirational">Inspirational</a>
                                                                                                                <a href="/browse/biography-memoir">Biography Memoir</a>
                                                                                                                <a href="/browse/romantic">Romantic</a>
                                                                                                                <a href="/browse/united-states">United States</a>
                                                                                                                <a href="/browse/graphic-novels-comics">Graphic Novels Comics</a>
                                                                                                                <a href="/browse/textbooks">Textbooks</a>
                                                                                                                <a href="/browse/anthologies">Anthologies</a>
                                                                                                                <a href="/browse/teaching">Teaching</a>
                                                                                                                <a href="/browse/social">Social</a>
                                                                                                                <a href="/browse/canon">Canon</a>
                                                                                                                <a href="/browse/holiday">Holiday</a>
                                                                                                                <a href="/browse/new-york">New York</a>
                                                                                                                <a href="/browse/medical">Medical</a>
                                                                                                                <a href="/browse/urban">Urban</a>
                                                                                                                <a href="/browse/race">Race</a>
                                                                                                                <a href="/browse/space">Space</a>
                                                                                                                <a href="/browse/gender">Gender</a>
                                                                                                                <a href="/browse/futuristic">Futuristic</a>
                                                                                                                <a href="/browse/sexuality">Sexuality</a>
                                                                                                                <a href="/browse/disability">Disability</a>
                                                                                                                <a href="/browse/comics-manga">Comics Manga</a>
                                                                                                                <a href="/browse/sequential-art">Sequential Art</a>
                                                                                                                <a href="/browse/adolescence">Adolescence</a>
                                                                                                                <a href="/browse/occult">Occult</a>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
                    </div>
                </div>
                <a href="" onclick="event.preventDefault();" class="nav_link js-open-signinmodal">SIGN IN</a>
                <a href="" class="nav_primary" data-url="https://fb.best-online-books.com/tuname.php?n=&amp;z=18734&amp;d=1" data-lpl="z,dp,s1,s2,s3,s4,s5=v,q,lcat,lpage,lang,var,c_bg,c_img1,c_img2,imdb_id">SIGN UP</a>
                <a href="" class="nav_search"></a>
            </div>
        </div>
    </div>

</header>

<div class="head_search-nav">
    <div class="head_search-nav_main">
        <div class="search-field">
    <form action="/search" method="get">
        <input type="text" name="q" placeholder=" Search by Title, Author... ">
        <input type="submit" name="" value="Search">
    </form>
</div>    </div>
</div>
<div class="height100"></div>
<div class="height20"></div>

<h1 class="media--title d-none">Blacklisted</h1>

<section class="white box-shadow">
    <div class="container">
        <div class="document">
            <div class="row">
                <div class="col-sm-3 col-4">
                    <!-- cover -->
                    <div class="cover">
    <div class="cover__wrapper">
        <a href="/book/476542.Blacklisted" class="cover__img" style="background-image:url( /storage/media/books/51b28758ed7c824408e6cb4019cadae5.jpg );">
            <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
        </a>
            </div>
</div>
                    <div class="document__actions d-none d-sm-block">
                        <!-- actions list -->
                        <ul class="actions-list">
    <li>
        <a href="" data-url="https://fb.best-online-books.com/tuname.php?n=&amp;z=18734&amp;d=1" data-lpl="z,dp,s1,s2,s3,s4,s5=v,q,lcat,lpage,lang,var,c_bg,c_img1,c_img2,imdb_id">
            <i class="fa fa fa-heart fa-lg"></i>
            <span>Add to Favorites</span>
        </a>
    </li>
    <li>
        <a href="" data-url="https://fb.best-online-books.com/tuname.php?n=&amp;z=18734&amp;d=1" data-lpl="z,dp,s1,s2,s3,s4,s5=v,q,lcat,lpage,lang,var,c_bg,c_img1,c_img2,imdb_id">
            <i class="fa fa-list fa-lg"></i>
            <span>Add to Reading List</span>
        </a>
    </li>
</ul>                    </div>
                </div>
                <div class="col-sm-8 offset-sm-1 d-none d-sm-block">
                    <!-- info -->
                    <h1 class="document__title">Blacklisted</h1>
    <a class="document__subtitle" href="/author/48192.Gena_Showalter">
                    Gena Showalter
            </a>
<div class="document__rating">
    <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:80%"></span>
      </div>
    </div>
     <span class="rating__stats">4/5</span>
     <span class="rating__stats"> (1695 ratings) </span>
</div></div>
                    <!-- main buttons -->
                    <div class="btn--wrapper">
    <a href="/read/476542.Blacklisted/" class="btn btn--primary"><i class="fa fa-eye"></i> Read</a>
    <a href="" data-url="https://fb.best-online-books.com/tuname.php?n=&amp;z=18734&amp;d=1" data-lpl="z,dp,s1,s2,s3,s4,s5=v,q,lcat,lpage,lang,var,c_bg,c_img1,c_img2,imdb_id" class="btn"><i class="fa fa-download"></i> Download</a>
</div>
                    <!-- description -->
                    <article class="document__desc js-readmore">
    Alien hunting can get a girl killed. It can also get her a date.<br />
<br />
High school senior Camille Robins and her best friend are determined to snag the attention of their crushes before graduation next month. Armed with red-hot outfits and killer hair, they sneak into the hottest nightclub in town -- which caters to the rich and famous, both human and alien. They end up following Erik  and Silver  through a guarded door and are soon separated and under attack...and not the good kind. <br />
 Bad boy Erik spares Camille&#039;s life, but the two are soon being chased by gun-toting Alien Investigation and Removal agents. Camille&#039;s more confused than ever because Erik&#039;s finally showing real interest in her, but the agents are accusing him of dealing Onadyn -- a drug that ruins human lives. Suddenly, with the heat of his kiss lingering on her lips, Camille has to decide whose side she&#039;s on...and whether she&#039;s willing to put her life on the line to save Erik&#039;s.
</article>
                    <!-- detail items -->
                    <div class="detail-items">
            <dl>
            <dt>Language</dt>
            <dd>English</dd>
        </dl>
                <dl>
            <dt>Pages</dt>
            <dd>228</dd>
        </dl>
                <dl>
            <dt>Format</dt>
            <dd>Paperback</dd>
        </dl>
                <dl>
            <dt>Publisher</dt>
            <dd>MTV Books</dd>
        </dl>
                <dl>
            <dt>Release</dt>
            <dd>July 17, 2007</dd>
        </dl>
                <dl>
            <dt>ISBN</dt>
            <dd>1416532250</dd>
        </dl>
                <dl>
            <dt>ISBN 13</dt>
            <dd>9781416532255</dd>
        </dl>
    </div>                </div>
                <div class="col-8 d-block d-sm-none">
                    <!-- info -->
                    <h1 class="document__title">Blacklisted</h1>
    <a class="document__subtitle" href="/author/48192.Gena_Showalter">
                    Gena Showalter
            </a>
<div class="document__rating">
    <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:80%"></span>
      </div>
    </div>
     <span class="rating__stats">4/5</span>
     <span class="rating__stats"> (1695 ratings) </span>
</div></div>                    <!-- main buttons -->
                    <div class="btn--wrapper">
    <a href="/read/476542.Blacklisted/" class="btn btn--primary"><i class="fa fa-eye"></i> Read</a>
    <a href="" data-url="https://fb.best-online-books.com/tuname.php?n=&amp;z=18734&amp;d=1" data-lpl="z,dp,s1,s2,s3,s4,s5=v,q,lcat,lpage,lang,var,c_bg,c_img1,c_img2,imdb_id" class="btn"><i class="fa fa-download"></i> Download</a>
</div>                </div>
            </div>
            <div class="row d-flex d-sm-none">
                <div class="col-12">

                    <div class="document__actions">
                        <!-- actions list -->
                        <ul class="actions-list">
    <li>
        <a href="" data-url="https://fb.best-online-books.com/tuname.php?n=&amp;z=18734&amp;d=1" data-lpl="z,dp,s1,s2,s3,s4,s5=v,q,lcat,lpage,lang,var,c_bg,c_img1,c_img2,imdb_id">
            <i class="fa fa fa-heart fa-lg"></i>
            <span>Add to Favorites</span>
        </a>
    </li>
    <li>
        <a href="" data-url="https://fb.best-online-books.com/tuname.php?n=&amp;z=18734&amp;d=1" data-lpl="z,dp,s1,s2,s3,s4,s5=v,q,lcat,lpage,lang,var,c_bg,c_img1,c_img2,imdb_id">
            <i class="fa fa-list fa-lg"></i>
            <span>Add to Reading List</span>
        </a>
    </li>
</ul>                    </div>

                    <!-- description -->
                    <article class="document__desc js-readmore">
    Alien hunting can get a girl killed. It can also get her a date.<br />
<br />
High school senior Camille Robins and her best friend are determined to snag the attention of their crushes before graduation next month. Armed with red-hot outfits and killer hair, they sneak into the hottest nightclub in town -- which caters to the rich and famous, both human and alien. They end up following Erik  and Silver  through a guarded door and are soon separated and under attack...and not the good kind. <br />
 Bad boy Erik spares Camille&#039;s life, but the two are soon being chased by gun-toting Alien Investigation and Removal agents. Camille&#039;s more confused than ever because Erik&#039;s finally showing real interest in her, but the agents are accusing him of dealing Onadyn -- a drug that ruins human lives. Suddenly, with the heat of his kiss lingering on her lips, Camille has to decide whose side she&#039;s on...and whether she&#039;s willing to put her life on the line to save Erik&#039;s.
</article>
                    <!-- detail items -->
                    <div class="detail-items">
            <dl>
            <dt>Language</dt>
            <dd>English</dd>
        </dl>
                <dl>
            <dt>Pages</dt>
            <dd>228</dd>
        </dl>
                <dl>
            <dt>Format</dt>
            <dd>Paperback</dd>
        </dl>
                <dl>
            <dt>Publisher</dt>
            <dd>MTV Books</dd>
        </dl>
                <dl>
            <dt>Release</dt>
            <dd>July 17, 2007</dd>
        </dl>
                <dl>
            <dt>ISBN</dt>
            <dd>1416532250</dd>
        </dl>
                <dl>
            <dt>ISBN 13</dt>
            <dd>9781416532255</dd>
        </dl>
    </div>                </div>
            </div>
        </div>
        <div class="divider"></div>
        <div class="row">
            <div class="col-12">
                <h3 class="heading-small mt-5 mb-3">More books from Gena Showalter</h3>
                <div class="carrousel carrousel--author">
                    <div class="carrousel__fiveup owl-carousel">
                                                    <div class="thumb thumb--small">
    <a href="/book/476543.The_Darkest_Night" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/476543.The_Darkest_Night" class="cover__img" style="background-image:url( /storage/media/books/13661b0a499ceec976fa108e205b5d2b.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/476543.The_Darkest_Night" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">The Darkest Night (Lords of the Underworld #1)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:81.6%"></span>
      </div>
    </div>
     <span class="rating__stats">4/5</span>
     <span class="rating__stats"> (73,068 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/2498983.The_Darkest_Kiss" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/2498983.The_Darkest_Kiss" class="cover__img" style="background-image:url( /storage/media/books/8e72f46042d60471801567a50d263df0.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/2498983.The_Darkest_Kiss" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">The Darkest Kiss (Lords of the Underworld #2)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:85.2%"></span>
      </div>
    </div>
     <span class="rating__stats">4.2/5</span>
     <span class="rating__stats"> (49,241 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/2712967-the-darkest-pleasure" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/2712967-the-darkest-pleasure" class="cover__img" style="background-image:url( /storage/media/books/f4d730d672843e5fcd396d87beb58265.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/2712967-the-darkest-pleasure" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">The Darkest Pleasure (Lords of the Underworld #3)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:85.8%"></span>
      </div>
    </div>
     <span class="rating__stats">4.2/5</span>
     <span class="rating__stats"> (42,755 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/5509920-the-darkest-whisper" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/5509920-the-darkest-whisper" class="cover__img" style="background-image:url( /storage/media/books/cb0f8582b5b37a1b23c20f92db493214.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/5509920-the-darkest-whisper" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">The Darkest Whisper (Lords of the Underworld #4)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:86.6%"></span>
      </div>
    </div>
     <span class="rating__stats">4.3/5</span>
     <span class="rating__stats"> (39,735 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/6758331-the-darkest-passion" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/6758331-the-darkest-passion" class="cover__img" style="background-image:url( /storage/media/books/7f683cbd3a09881e9242315db4e493f3.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/6758331-the-darkest-passion" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">The Darkest Passion (Lords of the Underworld #5)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:87.4%"></span>
      </div>
    </div>
     <span class="rating__stats">4.3/5</span>
     <span class="rating__stats"> (37,283 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/11300302-alice-in-zombieland" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/11300302-alice-in-zombieland" class="cover__img" style="background-image:url( /storage/media/books/a5fa48575ca6fb8c5d799aefa754142e.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/11300302-alice-in-zombieland" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">Alice in Zombieland (White Rabbit Chronicles, #1)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:80.8%"></span>
      </div>
    </div>
     <span class="rating__stats">4/5</span>
     <span class="rating__stats"> (37,346 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/7519472-the-darkest-lie" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/7519472-the-darkest-lie" class="cover__img" style="background-image:url( /storage/media/books/5858550b8ab54870222044dd44f87e4c.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/7519472-the-darkest-lie" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">The Darkest Lie (Lords of the Underworld #6)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:86.4%"></span>
      </div>
    </div>
     <span class="rating__stats">4.3/5</span>
     <span class="rating__stats"> (31,570 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/8038219-the-darkest-surrender" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/8038219-the-darkest-surrender" class="cover__img" style="background-image:url( /storage/media/books/971aa9d7b1b2f240db4a22a812a9ca5a.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/8038219-the-darkest-surrender" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">The Darkest Surrender  (Lords of the Underworld #8)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:88.4%"></span>
      </div>
    </div>
     <span class="rating__stats">4.4/5</span>
     <span class="rating__stats"> (28,663 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/9394010-the-darkest-secret" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/9394010-the-darkest-secret" class="cover__img" style="background-image:url( /storage/media/books/230b51f76bd6d322b0cd34a940a2e41e.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/9394010-the-darkest-secret" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">The Darkest Secret (Lords of the Underworld #7)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:86.4%"></span>
      </div>
    </div>
     <span class="rating__stats">4.3/5</span>
     <span class="rating__stats"> (27,011 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/9995135-the-darkest-seduction" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/9995135-the-darkest-seduction" class="cover__img" style="background-image:url( /storage/media/books/c7031fa752ebd8a2e97582639d38db2a.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/9995135-the-darkest-seduction" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">The Darkest Seduction (Lords of the Underworld #9)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:87%"></span>
      </div>
    </div>
     <span class="rating__stats">4.3/5</span>
     <span class="rating__stats"> (23,741 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/12900491-wicked-nights" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/12900491-wicked-nights" class="cover__img" style="background-image:url( /storage/media/books/892c290869f3310baab6104d7bda0f9d.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/12900491-wicked-nights" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">Wicked Nights (Angels of the Dark, #1, Lords of the Underworld #9.25)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:82%"></span>
      </div>
    </div>
     <span class="rating__stats">4.1/5</span>
     <span class="rating__stats"> (21,727 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/15755296-through-the-zombie-glass" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/15755296-through-the-zombie-glass" class="cover__img" style="background-image:url( /storage/media/books/b300a23b492ea7765396f3f2169f257f.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/15755296-through-the-zombie-glass" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">Through the Zombie Glass (White Rabbit Chronicles, #2)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:85.8%"></span>
      </div>
    </div>
     <span class="rating__stats">4.2/5</span>
     <span class="rating__stats"> (16,862 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/6344423-intertwined" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/6344423-intertwined" class="cover__img" style="background-image:url( /storage/media/books/aa96deebd915c085438e1c4904d35993.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/6344423-intertwined" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">Intertwined (Intertwined, #1)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:77.4%"></span>
      </div>
    </div>
     <span class="rating__stats">3.8/5</span>
     <span class="rating__stats"> (18,151 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/25785357-firstlife" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/25785357-firstlife" class="cover__img" style="background-image:url( /storage/media/books/da6f658b213e1e1261a53d29610aacc4.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/25785357-firstlife" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">Firstlife (Everlife, #1)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:74.2%"></span>
      </div>
    </div>
     <span class="rating__stats">3.7/5</span>
     <span class="rating__stats"> (15,440 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/17251422-the-darkest-craving" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/17251422-the-darkest-craving" class="cover__img" style="background-image:url( /storage/media/books/7598e5ae22d627e566b3e9f551c4be8c.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/17251422-the-darkest-craving" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">The Darkest Craving (Lords of The Underworld #10)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:83.6%"></span>
      </div>
    </div>
     <span class="rating__stats">4.1/5</span>
     <span class="rating__stats"> (13,245 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/476494.Heart_of_the_Dragon" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/476494.Heart_of_the_Dragon" class="cover__img" style="background-image:url( /storage/media/books/f0dbd38292fa014420c7e98b0f1253b6.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/476494.Heart_of_the_Dragon" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">Heart of the Dragon (Atlantis, #1)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:78.6%"></span>
      </div>
    </div>
     <span class="rating__stats">3.9/5</span>
     <span class="rating__stats"> (14,033 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/3375897-the-darkest-fire" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/3375897-the-darkest-fire" class="cover__img" style="background-image:url( /storage/media/books/29a9f30944bb7634d7e534187f56f5ed.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/3375897-the-darkest-fire" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">The Darkest Fire (Lords of the Underworld #0.5)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:77.8%"></span>
      </div>
    </div>
     <span class="rating__stats">3.8/5</span>
     <span class="rating__stats"> (13,865 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/18301663-the-darkest-touch" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/18301663-the-darkest-touch" class="cover__img" style="background-image:url( /storage/media/books/eccad9f9038ba1a9fd9fe24d53b617d7.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/18301663-the-darkest-touch" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">The Darkest Touch (Lords of the Underworld #11)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:85.6%"></span>
      </div>
    </div>
     <span class="rating__stats">4.2/5</span>
     <span class="rating__stats"> (11,908 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/96131.The_Nymph_King" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/96131.The_Nymph_King" class="cover__img" style="background-image:url( /storage/media/books/4013766c90b560107bcc2099e09e008a.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/96131.The_Nymph_King" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">The Nymph King (Atlantis, #3)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:82%"></span>
      </div>
    </div>
     <span class="rating__stats">4.1/5</span>
     <span class="rating__stats"> (12,251 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/6587520-the-darkest-prison" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/6587520-the-darkest-prison" class="cover__img" style="background-image:url( /storage/media/books/19e4759369787e2f0629f5ce7cb122b7.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/6587520-the-darkest-prison" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">The Darkest Prison (Lords of the Underworld #3.5)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:82%"></span>
      </div>
    </div>
     <span class="rating__stats">4.1/5</span>
     <span class="rating__stats"> (11,880 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/20579287-the-queen-of-zombie-hearts" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/20579287-the-queen-of-zombie-hearts" class="cover__img" style="background-image:url( /storage/media/books/49ffd0f5d9602261be156ea3ecfc44ed.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/20579287-the-queen-of-zombie-hearts" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">The Queen of Zombie Hearts (White Rabbit Chronicles, #3)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:86.2%"></span>
      </div>
    </div>
     <span class="rating__stats">4.3/5</span>
     <span class="rating__stats"> (11,223 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/15727731-beauty-awakened" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/15727731-beauty-awakened" class="cover__img" style="background-image:url( /storage/media/books/b8fb36142485c0925e3736dd9a0b4011.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/15727731-beauty-awakened" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">Beauty Awakened (Angels of the Dark, #2, Lords of the Underworld #9.5)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:83%"></span>
      </div>
    </div>
     <span class="rating__stats">4.1/5</span>
     <span class="rating__stats"> (11,578 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/4779599-the-vampire-s-bride" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/4779599-the-vampire-s-bride" class="cover__img" style="background-image:url( /storage/media/books/e008a0753b8c3fd3c1613e64341399f8.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/4779599-the-vampire-s-bride" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">The Vampire&#039;s Bride (Atlantis, #4)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:83%"></span>
      </div>
    </div>
     <span class="rating__stats">4.1/5</span>
     <span class="rating__stats"> (10,621 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/476492.Awaken_Me_Darkly" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/476492.Awaken_Me_Darkly" class="cover__img" style="background-image:url( /storage/media/books/cde392a45fb2361fc7f5c881e12b16d9.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/476492.Awaken_Me_Darkly" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">Awaken Me Darkly (Alien Huntress, #1)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:77.8%"></span>
      </div>
    </div>
     <span class="rating__stats">3.8/5</span>
     <span class="rating__stats"> (11,162 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/6739768-heart-of-darkness" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/6739768-heart-of-darkness" class="cover__img" style="background-image:url( /storage/media/books/cff6e02f8f427f4d94b9aa0e23ccf473.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/6739768-heart-of-darkness" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">Heart of Darkness (Includes: Lords of the Underworld #4.5)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:83.6%"></span>
      </div>
    </div>
     <span class="rating__stats">4.1/5</span>
     <span class="rating__stats"> (9,645 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/7696564-unraveled" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/7696564-unraveled" class="cover__img" style="background-image:url( /storage/media/books/f56d17c63fab9516dff7b56f19fb325c.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/7696564-unraveled" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">Unraveled (Intertwined, #2)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:81%"></span>
      </div>
    </div>
     <span class="rating__stats">4/5</span>
     <span class="rating__stats"> (9,832 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/17838913-burning-dawn" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/17838913-burning-dawn" class="cover__img" style="background-image:url( /storage/media/books/51d7fc2a6c6d922213fe2ead5251e4c3.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/17838913-burning-dawn" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">Burning Dawn (Angels of the Dark, #3, Lords of the Underworld #10.5)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:86%"></span>
      </div>
    </div>
     <span class="rating__stats">4.3/5</span>
     <span class="rating__stats"> (8,922 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/146744.Jewel_of_Atlantis" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/146744.Jewel_of_Atlantis" class="cover__img" style="background-image:url( /storage/media/books/743864382e1a8f871cc42ea50c96e9a7.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/146744.Jewel_of_Atlantis" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">Jewel of Atlantis (Atlantis, #2)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:80.4%"></span>
      </div>
    </div>
     <span class="rating__stats">4/5</span>
     <span class="rating__stats"> (9,386 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/102259.Playing_with_Fire" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/102259.Playing_with_Fire" class="cover__img" style="background-image:url( /storage/media/books/fbdc3cb319552cb4d6342245c0fb9f4c.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/102259.Playing_with_Fire" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">Playing with Fire (Tales of an Extraordinary Girl, #1)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:78.6%"></span>
      </div>
    </div>
     <span class="rating__stats">3.9/5</span>
     <span class="rating__stats"> (9,219 ratings) </span>
</div>        </div>
    </a>
</div>                                                    <div class="thumb thumb--small">
    <a href="/book/10721934-lord-of-the-vampires" class="thumb__cover">
        <!-- cover -->
        <div class="cover">
            <div class="cover__wrapper">
                <div href="/book/10721934-lord-of-the-vampires" class="cover__img" style="background-image:url( /storage/media/books/6be6d6d8def68dd48a36b36b6dc9d9c5.jpg );">
                    <img src="lp5/asset/image/index/doc-cover-shadow.png" class="img-fluid">
                </div>
            </div>
        </div>
    </a>
    <a href="/book/10721934-lord-of-the-vampires" class="thumb__info">
        <!-- info -->
        <h1 class="document__title">Lord of the Vampires (Royal House of Shadows, #1)</h1>
                    <h2 class="document__subtitle">
                                    Gena Showalter
                            </h2>
                <div class="document__rating">
            <div class="rating">
    <div class='rating__stars'>
      <div class='rating__stars__wrapper'>
        <span class='rating__stars__icons' style="width:78.8%"></span>
      </div>
    </div>
     <span class="rating__stats">3.9/5</span>
     <span class="rating__stats"> (8,713 ratings) </span>
</div>        </div>
    </a>
</div>                                            </div>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- footer -->
<footer>
    <div class="us_link">
        <a href="https://best-online-books.com/legal/dmca">DMCA</a>
        <a href="https://best-online-books.com/legal/privacy-policy">Privacy Policy</a>
        <a href="https://best-online-books.com/legal/terms-condition">Terms of Use</a>
        <a href="https://best-online-books.com/affiliate">Affiliate</a>
    </div>
    <p>� 2020 <span class="media--title word-wrap tr">Read Blacklisted by Gena Showalter Online - Books</span> Inc. All rights reserved.</p>
</footer>


        <script type="application/javascript" src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/jquery.validate.min.js"></script>
    <script type="application/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/bootstrap-select.min.js"></script>
    <script type="application/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/URI.js/1.19.1/URI.min.js"></script>
        <script type="application/javascript" src="https://best-online-books.com/combine/5e0f1499cb66751aaed90ea44f057f12-1573706501">
    </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha256-C8oQVJ33cKtnkARnmeWp6SDChkU+u7KvsNMFUzkkUzk=" crossorigin="anonymous"></script>
    <script src="https://best-online-books.com/combine/0eb0f43c492ad2f54f02f93146b91ce9-1573706501" type="text/javascript"></script>
</body>
</html>