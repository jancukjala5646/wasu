<?php
$ssl			= 'http'; // jika mau pakai ssl/https rubah valuenya disini
$domain			= ''.$ssl.'://'.$_SERVER['HTTP_HOST'];
$domen 			= $_SERVER['HTTP_HOST'];
$lpdomain		= $domen;
$agclist		= 'pop';
$enginepdf		= 'fpdf'; // engine yang tersedia saat ini dompdpf,mpdf dan fpdf
$Premium		= 'http://look.djfiln.com/offer?prod=2&ref=5161312'; // Ganti Offer disini
$Biasa			= 'http://affforce.com/scripts/un981c6l?a_aid=1f0f6f26&a_bid=b33c89d7'; // Ganti Offer disini
$niche			= 'manualbooks'; //ini adalah nama folder sitemap
$site_name		= 'Ebook and Manual Reference'; // Ganti Nama Web anda Agar Lebih Unik
$site_description	= 'Get Free Download Ebook and Manual Reference';  // Ganti Deskripsi Web anda Agar Lebih Unik
$site_keyword		= 'Free Ebook Download,Download Ebook Free,Free PDF Books'; // Ganti Keyword Web anda Agar Lebih Unik
$fformat		= 'pdf';
$negara			= 'com';
$feed			= '5000'; //Untuk Menampilkan Berapa Url di feed (Google Menyarankan Maksimal 500 Post didalam Feed)
$linkstyle		= '_'; // untuk merubah style url pakai strip - atau underscore _ atau apapun bebas
$slugpost		= 'download/'; //Untuk Merubah Slug keyword + Slash  misalkan ebook/
$linkfont		= 'ucwords'; // untuk mengubah font permalink yg tersedia strtolower,ucwords dan strtoupper
$sizepdf		= 'custom';  //ukuran yang tersedia halaman pdf (letter,legal,ledger,tabloid,executive,folio)
$paperstyle             = 'portrait'; // Style yg tersedia dihalaman pdf hanya (portrait dan landscape)
$lang			= 'en-US';
$imgna			= '/na.jpg';
$unixurlcode		= 'Printable-2020';
$kw			= 'KEY/pop.txt';
$fontpdf		= '{Agency FB|Albertina|Antiqua|Architect|Arial|BankFuturistic|BankGothic|Blackletter|Blagovest|Calibri|Comic Sans MS|Courier|Cursive|Decorative|Fantasy|Fraktur|Frosty|Garamond|Georgia|Helvetica|Impact|Minion|Modern|Monospace|Open Sans|Palatino|Perpetua|Roman|Sans-serif|Serif|Script|Swiss|Times|Times New Roman|Tw Cen MT|Verdana}';
$spinjudul		= '{Download Here:|Free Download:|Download:|Download Now:|Download PDF:}';
$spinjudul2		= '{Read Online|Online Reading|Read E-Book Online|Free Reading|Reading Free}';
$singledesc = '%booktitle% is {the best|big|most popular}  {want|must read|need}.   {get|download|read}  %booktitle% in {simple|easy} step and you can {download|get|save|read full version}.||{The big|The most popular|Popular|Best|Great|Nice} ebook you {should|must|want to} read is %booktitle%. {I am|We are} {sure|promise} {love|like} the %booktitle%. download  {computer|laptop|smartphone} {with|in|through} {simple|easy|light} steps.||Are you {looking for|search|trying to find} %booktitle%? {Then you|Then you definitely|You then|Then you certainly} come {to the right|right|off to the right|to the correct} {to get the|to obtain the|to find the|to have the} %booktitle%. {You can read|Read|Look for|Search for}  {easy steps|simple steps|basic steps|simple actions}.   {save|download|get}  {computer|laptop|smartphone},  download {much|more} ebooks.||Download {big|most popular|popular|best|great|nice} ebook read the %booktitle% ebook. {You will not|You won\'t|You\'ll not|You can\'t}. {Read the|Browse the|See the|Look at}  {if you do not|if you don\'t|unless you|should you not} have {a lot of time|considerable time|lots of time|time and effort} {to read|to see|to learn|you just read}, {you can|you are able to|it is possible to|you\'ll be able to} download {to your|for your|in your|on your} {computer|laptop|smartphone|device} and {read|check} {offline|next time}.';
$singledesc2 = '{We all know|Everyone knows|Everybody knows|You know} reading %booktitle%  {is beneficial|is helpful|is effective|is useful}, {we can|we are able to|we could|we can easily}  {a lot of information|enough detailed information online|information|too much info online} {from the|in the|from your|through the} {reading materials|resources}. {Technology has|Technologies have} developed, and reading %booktitle%  books {can be|could be|may be|might be} {more convenient|easier|far more convenient|far easier} {and easier|and simpler|and much easier}. {You can|You are able to|You could|You can easily} read books {on our|on the} Offline, {there are many|there are lots of|there are numerous|there are several} Ebooks {coming into|entering|getting into|being received by} PDF format. {Below are some|Listed below are some|Right here|Several} {downloading|download|get free}  {PDF books|Ebooks|PDF} {where you can|where one can|to|which you could}  {as much|just as much|the maximum amount of|all the} {information|reference|guide} {as you want|as you would like|as you wish|as you desire}.';
$email = 'blogsyera@gmail.com'; //Ganti Dengan Email Anda yang Mudah dihubungi bila ada complain DMCA 
?>