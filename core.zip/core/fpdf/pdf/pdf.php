<?php
$acak = rand( 1, 2);
//include('pdf'.$acak.'.php');
include('latihan.php');

?>
